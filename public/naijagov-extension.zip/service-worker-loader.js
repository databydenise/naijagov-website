import './assets/service-worker.ts-C_SGSumi.js';
