import './assets/service-worker.ts-D0gaYHdn.js';
